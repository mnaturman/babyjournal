import React from 'react';

function TestComponent() {
  return <div>Test Component</div>;
}

export default TestComponent;
